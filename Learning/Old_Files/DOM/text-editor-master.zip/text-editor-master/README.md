A simple rich text editor.<br>
I was just curious about how rich text editors worked.


<img src="screenshot/img.PNG"/>